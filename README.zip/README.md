# SystemMonitorApp

## 📦 Description
A console-based system resource monitoring app using .NET. It tracks CPU, memory, and disk usage and logs it using a plugin system.

## ⚙️ Features
- Monitors system resources
- Plugin-based logging (e.g., File Logger)
- Configurable via `appsettings.json`

## 🚀 How to Run

1. Install [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
2. Clone or unzip this repo.
3. Open the folder in Visual Studio Code.
4. Run the following in terminal:
    ```
    dotnet run
    ```

## 🧩 Plugins
The app loads plugins based on `appsettings.json`. Example:

```json
{
  "Plugins": {
    "Enabled": [ "FileLoggerPlugin" ]
  }
}
